package test.java;

import org.example.SetMerger;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SetMergerTest {

    private final SetMerger setMerger = new SetMerger();

    @Test
    public void testMergeSetsWithNoIntersection() {
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(4, 5, 6));

        Set<Integer> result = setMerger.mergeSets(set1, set2);

        System.out.println("The result of the union of sets without intersection: " + result);
        assertEquals(new HashSet<>(Arrays.asList(1, 2, 3, 4, 5, 6)), result);
    }

    @Test
    public void testMergeSetsWithIntersection() {
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(3, 4, 5));

        Set<Integer> result = setMerger.mergeSets(set1, set2);

        System.out.println("The result of the union of sets with intersection: " + result);
        assertEquals(new HashSet<>(Arrays.asList(1, 2, 3, 4, 5)), result);
    }
}