import org.example.UniqueNumberExtractor;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class UniqueNumberExtractorTest {
    @Test
    public void testExtractUniqueNumbersWithDuplicates() {
        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 1, 5, 3);

        Set<Integer> expectedUniqueNumbers = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5));
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectedUniqueNumbers, actualUniqueNumbers, "The unique numbers should match the expected set. ");
    }

    @Test
    public void testExtractUniqueNumbersEmptyList() {
        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList();

        Set<Integer> expectedUniqueNumbers = new HashSet<>();
        Set<Integer> actualUniqueNumbers =  extractor.extractUniqueNumbers(numbers);

        assertEquals(expectedUniqueNumbers, actualUniqueNumbers, "The unique numbers from an empty list be an empty set.");
    }

    @Test
    public void testExtractUniqueNumbersNoDuplicates() {
        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        Set<Integer> expectUniqueNumbers = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5));
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectUniqueNumbers, actualUniqueNumbers, "The unique numbers should match the input when there are no dublicates. ");
    }

    @Test
    public void testExtractUniqueNumbersWithNegativeNumbers() {
        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList(-1, -2, -3, -2, -1, 0);

        Set<Integer> expectUniqueNumbers = new HashSet<>(Arrays.asList(-1, -2, -3, 0));
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectUniqueNumbers, actualUniqueNumbers, "The unique numbers should match the input when there are no dublicates. ");

    }

    @Test
    public void testExtractUniqueNumbersAllDuplicates() {
        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList(2, 2, 2, 2);

        Set<Integer> expectUniqueNumbers = new HashSet<>(Arrays.asList(2));
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectUniqueNumbers, actualUniqueNumbers, "The unique numbers should match the input when there are no dublicates. ");
    }
}


