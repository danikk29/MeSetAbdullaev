package org.java;

import org.example.SetDifferenceCalculator;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SetDifferenceCalculatorTest {

    private final SetDifferenceCalculator setDifferenceCalculator = new SetDifferenceCalculator();

    @Test
    public void testCalculateDifferenceWithNoIntersection() {
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(4, 5, 6));

        Set<Integer> result = setDifferenceCalculator.calculateDifference(set1, set2);

        System.out.println("Difference of sets without intersection: " + result);
        assertEquals(new HashSet<>(Arrays.asList(1, 2, 3)), result);
    }

    @Test
    public void testCalculateDifferenceWithSomeIntersection() {
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3, 4));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(3, 4, 5, 6));

        Set<Integer> result = setDifferenceCalculator.calculateDifference(set1, set2);

        System.out.println("Difference of sets with some intersection: " + result);
        assertEquals(new HashSet<>(Arrays.asList(1, 2)), result);
    }

    @Test
    public void testCalculateDifferenceWhereFirstIsSubset() {
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5));

        Set<Integer> result = setDifferenceCalculator.calculateDifference(set1, set2);

        System.out.println("Difference of sets, where the first is a subset: " + result);
        assertEquals(new HashSet<>(), result);
    }

    @Test
    public void testCalculateDifferenceWithEmptyFirstSet() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>(Arrays.asList(4, 5, 6));

        Set<Integer> result = setDifferenceCalculator.calculateDifference(set1, set2);

        System.out.println("Difference of sets, where the first is a subset: " + result);
        assertEquals(new HashSet<>(), result);
    }
}
