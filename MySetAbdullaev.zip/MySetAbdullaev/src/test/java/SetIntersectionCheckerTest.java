import static org.junit.jupiter.api.Assertions.*;
import org.example.SetIntersectionChecker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.HashSet;
import java.util.Set;
public class SetIntersectionCheckerTest {
    private SetIntersectionChecker checker;
    @BeforeEach
    public void setUp() {
        checker = new SetIntersectionChecker();
    }
    @Test
    public void testSetsWithCommonElement() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(3, 4, 5));
        assertTrue(checker.isIntersection(set1, set2));
    }
    @Test
    public void testSetsWithoutCommonElement() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(4, 5, 6));
        assertFalse(checker.isIntersection(set1, set2));
    }
    @Test
    public void testFirstSetEmpty() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>(Set.of(1, 2, 3));
        assertFalse(checker.isIntersection(set1, set2));
    }
    @Test
    public void testSecondSetEmpty() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>();
        assertFalse(checker.isIntersection(set1, set2));
    }
    @Test
    public void testBothSetsEmpty() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();

        assertFalse(checker.isIntersection(set1, set2));
    }
    @Test
    public void testSetsWithSameElements() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(1, 2, 3));
        assertTrue(checker.isIntersection(set1, set2));
    }
    @Test
    public void testSetsWithNegativeNumbers() {
        Set<Integer> set1 = new HashSet<>(Set.of(-1, -2, -3));
        Set<Integer> set2 = new HashSet<>(Set.of(3, -2, 5));
        assertTrue(checker.isIntersection(set1, set2));
    }
}